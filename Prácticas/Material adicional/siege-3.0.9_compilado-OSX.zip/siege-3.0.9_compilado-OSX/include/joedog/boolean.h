/**
 * Copyright (C) 2002-2013 by
 * Jeffrey Fulmer - <jeff@joedog.org>, et al.
 * This file is distributed as part of Siege
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *--
 */
#ifndef BOOLEAN_H
#define BOOLEAN_H 
 
typedef enum {boolean_false=0,boolean_true=1}                      BOOLEAN;
typedef enum {toolean_false=0,toolean_true=1,toolean_undefined=-1} TOOLEAN;
 
#ifndef  FALSE
# define FALSE     boolean_false
#endif /*FALSE*/

#ifndef  TRUE
# define TRUE      boolean_true
#endif /*TRUE*/

#ifndef  UNDEFINED
# define UNDEFINED toolean_undefined
#endif /*UNDEFINED*/
 
#endif/*BOOLEAN_H*/
